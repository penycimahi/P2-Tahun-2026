import streamlit as st
import pandas as pd
import numpy as np
import plotly_express as px
from PIL import Image

# load model 
# import joblib
import pickle

def main():
    """App with Streamlit"""
    st.title("Hello Data Analyst!")
        
    st.subheader("Iris flower Prediction from Machine Learning Model")

    # model= open("model.pkl", "rb")
    # knn_clf=joblib.load(model)
    knn_clf = pickle.load(open('model.pkl', 'rb'))
    #Loading images
    st.image(Image.open('iris.png'))
    setosa= Image.open('setosa.png')
    versicolor= Image.open('versicolor.png')
    virginica = Image.open('virginica.png')

    st.title("Features")
    #Intializing
    sl = st.slider(label="Sepal Length (cm)",value=5.2,min_value=0.0, max_value=8.0, step=0.1)
    sw = st.slider(label="Sepal Width (cm)",value=3.2,min_value=0.0, max_value=8.0, step=0.1)
    pl = st.slider(label="Petal Length (cm)",value=4.2,min_value=0.0, max_value=8.0, step=0.1)
    pw = st.slider(label="Petal Width (cm)",value=1.2,min_value=0.0, max_value=8.0, step=0.1)

    if st.button("Click Here to Classify"):
        dfvalues = pd.DataFrame(list(zip([sl],[sw],[pl],[pw])),columns =['sepal_length', 'sepal_width', 'petal_length', 'petal_width'])
        input_variables = np.array(dfvalues[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']])
        prediction = knn_clf.predict(input_variables)
        if prediction == 1:
            st.image(setosa)
            st.title("Just Leave It..")
        elif prediction == 2:
            st.image(versicolor)
            st.title("Just Leave It..")
        elif prediction == 3:
            st.image(virginica)
            st.title("Get It !!")

if __name__=='__main__':
    main()